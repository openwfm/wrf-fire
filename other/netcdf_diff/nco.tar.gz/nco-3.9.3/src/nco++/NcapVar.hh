#ifndef NCAPVAR_HH
#define NCAPVAR_HH
#include <iostream>
#include <string>
#include "nco.h"
#include "ncap2.hh"
#include "nco_var_utl.h"  // nco_var_free()
#include <antlr/AST.hpp>
#include <antlr/AST.hpp>

ANTLR_USING_NAMESPACE(antlr);

class NcapVar{

private:
  std::string var_nm;
  std::string att_nm;
  std::string fll_nm; // full name i.e var_nm@att_nm;
  RefAST  rfr_ast;
  ncap_type xpr_typ_rfr; 
public:
 var_sct *var;
 ncap_type xpr_typ;
 
  bool flg_udf;   // matches var->undefined


 bool flg_mem;    // true -- then var data is written to memory  
                  // rather than disk -- At the moment all meta-data
                  // is cached  ? --     
 int flg_stt;      // status flag
                   // 0 -- var is defined in memory
                   // 1 -- var is defined in output - but no data written
                   // 2 -- var is defined & data written

public:

  //constructors n.b var->nm should match var_nm@att_nm

  NcapVar(var_sct *var_in, std::string sin="");

  // NcapVar(var_sct *var_in);

  //Copy Constructor
  NcapVar(NcapVar &Nvar){

   var_nm=Nvar.var_nm;;
   att_nm=Nvar.att_nm;
   fll_nm=Nvar.fll_nm; 
   rfr_ast=Nvar.rfr_ast;;

   xpr_typ_rfr=Nvar.xpr_typ_rfr; 

   var=nco_var_dpl(Nvar.var);
   xpr_typ=Nvar.xpr_typ;
 
   flg_udf=Nvar.flg_udf;
   flg_mem=Nvar.flg_mem;   
   flg_stt=Nvar.flg_stt;   
  } 
  

  //Copy variable type
  var_sct * cpyVar(){
    return nco_var_dpl(var);
  } 

  //Copy variable no data
  var_sct *cpyVarNoData(){
    void *vp;
    var_sct *var_ret;

    vp=var->val.vp;
    var->val.vp=(void*)NULL;
    var_ret=nco_var_dpl(var);
    
    // Restore Original Value
    var->val.vp=vp;

    return var_ret;
  }

  
  //Methods
  void setAST(RefAST &rAST) 
      { rfr_ast=rAST;} 
  void setAST(RefAST &rAST,ncap_type xpr_rtyp)
      { rfr_ast=rAST;
        xpr_typ_rfr=xpr_rtyp;
      } 
    

 
  RefAST getAst(){ return rfr_ast;}
  ncap_type getAst_typ() { return xpr_typ_rfr;}

  std::string getVar() {return var_nm; }
  std::string getAtt() {return att_nm; }
  std::string getFll() {return fll_nm; }

  //Destructor
  ~NcapVar() { if(var !=(var_sct*)NULL) var=nco_var_free(var); }


};


#endif // NCAPVAR_HH


