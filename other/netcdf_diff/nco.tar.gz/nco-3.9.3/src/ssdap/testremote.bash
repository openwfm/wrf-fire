#!/usr/bin/env bash
./swampsendscript.py chaining.ssdap http://localhost/cgi-bin/nph-dods globout.nc


