#!/usr/bin/env bash
./ssdwrap.py ncecat nc/foo_T42.nc myoutput.nc

