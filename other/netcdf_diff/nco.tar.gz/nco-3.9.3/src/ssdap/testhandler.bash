#!/usr/bin/env bash
bin/dap_nc_handler_hack -L -o dods -r /usr/tmp -e superduperscript11 -c -u http://localhost:8000/cgi/nph_dods/nc/foo_T42.nc -v DAP2/3.5.3 /home/wangd/opendap/aolserver4/servers/aoldap/pages/nc/foo_T42.nc <simplescript.ssdap

