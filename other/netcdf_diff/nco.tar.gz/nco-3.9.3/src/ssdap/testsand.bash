#!/usr/bin/env bash
./scriptwrap.py ncecatsand.ssdap http://sand.ess.uci.edu/cgi-bin/dods/nph-dods globout.nc


