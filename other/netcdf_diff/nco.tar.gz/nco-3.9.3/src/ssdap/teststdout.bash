#!/usr/bin/env bash
./scriptwrap.py stdout.ssdap http://localhost:8000/cgi/nph-dods 


