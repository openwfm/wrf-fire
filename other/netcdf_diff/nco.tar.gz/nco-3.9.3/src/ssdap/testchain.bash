#!/usr/bin/env bash
./dap_nc_swamp -L -o dods -r /tmp -e superduperscript11 -c -u http://localhost:8000/cgi/nph_dods/foo_T42.nc -v DAP2/3.5.3 /var/www/html/foo_T42.nc <chaining.ssdap

